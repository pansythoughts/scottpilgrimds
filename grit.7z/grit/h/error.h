
//{{BLOCK(error)

//======================================================================
//
//	error, 768x512@4, 
//	Transparent color : FF,00,FF
//	+ palette 16 entries, not compressed
//	+ 1004 tiles (t|f reduced) not compressed
//	+ regular map (in SBBs), not compressed, 96x64 
//	Total size: 32 + 32128 + 12288 = 44448
//
//	Time-stamp: 2025-01-28, 19:42:00
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.9
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_ERROR_H
#define GRIT_ERROR_H

#define errorTilesLen 32128
extern const unsigned int errorTiles[8032];

#define errorMapLen 12288
extern const unsigned short errorMap[6144];

#define errorPalLen 32
extern const unsigned short errorPal[16];

#endif // GRIT_ERROR_H

//}}BLOCK(error)
